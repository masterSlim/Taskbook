package sample;

public abstract class Task {

    int taskId;
    byte priority;
    int creatorsId;
    String title;
    String task;
    int executorsId;
    String createDateTime;
    String startDateTime;
    String closeDateTime;
    Boolean active;
}

