package sample;

public class User {

    int userId;
    String userName;
    String password;
    String userpick;
    boolean gender;
    String position;
    int phone;
    String email;
}
