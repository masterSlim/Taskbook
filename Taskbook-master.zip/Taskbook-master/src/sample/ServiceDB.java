package sample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ServiceDB {
    private static final String URL = "jdbc:mysql://creaz.ru:3306/u0441813_taskboo";

    public static Properties getProperties() {
        Properties properties = new Properties();
        properties.put("user", "u0441813_project");
        properties.put("password", "4E0a3H7c");
        properties.put("useSSL", "true");
        properties.put("serverTimezone", "Europe/Moscow");
        return properties;
    }

    public static Connection getConnection(Properties properties) {
        Connection connection = null;
        try{
            connection = DriverManager.getConnection(URL, properties);
            System.out.println("Подключение " +
                    (connection.isClosed() ? "закрыто" : "открыто"));
        } catch (SQLException e) {
            System.out.println("Ошибка создания подключения");
            e.printStackTrace();
        }
        return connection;
    }
}
