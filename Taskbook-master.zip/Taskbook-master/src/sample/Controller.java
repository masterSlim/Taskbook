package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;

import java.sql.Connection;
import java.util.Properties;

public class Controller {
    @FXML
    private Button buttonOk;
    @FXML
    private Button buttonCancel;
    @FXML
    private Button buttonLater;

    ServiceDB serviceDB = new ServiceDB();

    @FXML
    public void saveTask(ActionEvent event) {


    }

    public void addTask(MouseEvent mouseEvent) {
        Connection connection = serviceDB.getConnection(serviceDB.getProperties());
    }

    /*public void inputTeskDescription(InputMethodEvent inputMethodEvent) {
        String task = new String();

    }*/
}
